
## Base package

- this project created for base of tools and utils in data team.


### References

- [Setup package] https://towardsdatascience.com/create-your-custom-python-package-that-you-can-pip-install-from-your-git-repository-f90465867893
