
from json import loads
from json import dumps
from kafka import KafkaProducer
from kafka import KafkaConsumer
from kafka import TopicPartition
import rad_data.utils.helper as hp
from rad_data.utils.bunch import Bunch


class KafkaDataProducer(object):
    """
    Kafka data producer
    """

    def __init__(self, config: str or Bunch) -> None:
        """
        Initialize Kafka producer class
        Args:
            config: Get kafka config by file path or bunch object
        """
        self._producer = None
        if type(config) == str:
            self._config = hp.get_config(path=config).producer
        else:
            self._config = config.producer

    def __enter__(self):
        """
        Create kafka producer session
        """
        try:
            self._producer = KafkaProducer(bootstrap_servers=self._config.bootstrap_servers,
                                           value_serializer=lambda x: dumps(x).encode('utf8'))
            return self
        except Exception as e:
            print(f'Can not connect to kafka data producer, {e}')

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        close kafka producer connection
        """
        try:
            self._producer.close()
        except Exception as e:
            print(f'Kafka data producer close connection is failed, {e}')

    def produce_batch_data(self, docs: list, topic: str) -> bool:
        """
        Produce list of messages batch to kafka topic
        Args:
            docs: List of dictionary
            topic: Topic name for producing data
        Returns: Send data to kafka topic
        """
        try:
            for doc in docs:
                self._producer.send(topic=topic, value=doc)
            return True
        except Exception as e:
            print(f'Kafka data producer is failed, {e}')
            return False

    def produce_data(self, doc: dict, topic: str) -> bool:
        """
        Produce json object to kafka topic
        Args:
            doc: A dictionary of key values
            topic: Topic name for producing data
        Returns: Send data to kafka topic
        """
        try:
            result = self._producer.send(topic=topic, value=doc)
            print("Kafka data producer send result: {}".format(result.get()))
            return True
        except Exception as e:
            print(f'Kafka data producer is failed, {e}')
            return False
            

class KafkaDataConsumer(object):
    """
    Kafka data consumer
    """

    def __init__(self, config: str or Bunch) -> None:
        """
        Initialize Kafka data consumer class
        Args:
            config: Get kafka config by file path or bunch object
        """
        self._consumer = None
        if type(config) == str:
            self._config = hp.get_config(path=config).consumer
        else:
            self._config = config

    def __enter__(self):
        """
        Create kafka consumer session
        """
        try:
            self._consumer = KafkaConsumer(self._config.topic,
                                           group_id=self._config.group_id,
                                           max_poll_records=self._config.max_poll_records,
                                           bootstrap_servers=self._config.bootstrap_servers,
                                           auto_offset_reset=self._config.auto_offset_reset,
                                           enable_auto_commit=self._config.enable_auto_commit,
                                           sasl_plain_username=self._config.username,
                                           sasl_plain_password=self._config.password,
                                           value_deserializer=lambda x: loads(x.decode('utf8')))
            return self
        except Exception as e:
            print(f'Can not connect to kafka data consumer, {e}')

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Close kafka consumer connection
        """
        try:
            self._consumer.close()
        except Exception as e:
            print(f'Kafka data consumer close connection is failed, {e}')

    def consume_batch_data(self) -> list or None:
        """
        Consume list of batch data
        """
        try:
            timeout_second = self._config.get('timeout_second') * 1000
            msg = self._consumer.poll(timeout_ms=timeout_second)
            if msg:
                return [v.value for v in [value for key, value in msg.items()][0]]
            return []
        except Exception as e:
            print(f'Kafka data consume batch data is failed, {e}')
            return None

    def commit(self):
        """
        Commit documents and change offset
        """
        self._consumer.commit()


class KafkaPartitionConsumer(object):
    """
    Initialize Kafka partition consumer class
    """

    def __init__(self, config: str or Bunch) -> None:
        """
        Kafka partition consumer
        Args:
            config: Get kafka config by file path or bunch object
        """
        self._consumer = None
        if type(config) == str:
            self._config = hp.get_config(path=config).consumer
        else:
            self._config = config

    def __enter__(self):
        """
        :return: Kafka partition consumer session
        """
        try:
            self._consumer = KafkaConsumer(group_id=self._config.group_id,
                                           max_poll_records=self._config.max_poll_records,
                                           bootstrap_servers=self._config.bootstrap_servers,
                                           auto_offset_reset=self._config.auto_offset_reset,
                                           enable_auto_commit=self._config.enable_auto_commit,
                                           sasl_plain_username=self._config.username,
                                           sasl_plain_password=self._config.password,
                                           security_protocol=self._config.security_protocol,
                                           sasl_mechanism=self._config.sasl_mechanism,
                                           value_deserializer=lambda x: loads(x.decode('utf8')))
            return self
        except Exception as e:
            print(f'Can not connect to kafka partition consumer, {e}')

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Close kafka partition connection
        """
        try:
            self._consumer.close()
        except Exception as e:
            print(f'Kafka partition consumer close connection is failed, {e}')

    def consume_batch_data(self, partition: int, topic: str) -> list or None:
        """
        Consume list of batch data
        Args:
            partition: partition number
            topic: Topic name for consume data
        Returns: consume data from kafka topic partitions
        """
        try:
            timeout_second = self._config.get('timeout_second') * 1000
            self._consumer.assign([TopicPartition(topic, partition)])
            msg = self._consumer.poll(timeout_ms=timeout_second)
            if msg:
                return [v.value for v in [value for key, value in msg.items()][0]]
            return []
        except Exception as e:
            print(f'Kafka partition consume batch data is failed, {e}')
            return None

    def commit(self):
        """
        Commit documents and change offset
        """
        self._consumer.commit()
