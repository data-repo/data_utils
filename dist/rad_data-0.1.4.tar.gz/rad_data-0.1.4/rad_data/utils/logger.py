
import os
import json
import inspect
from enum import Enum
from datetime import datetime
import rad_data.utils.helper as hp
from rad_data.utils.bunch import Bunch
from rad_data.utils.kafka import KafkaDataProducer


class LoggerFormat(Enum):
    """
    Enum for logger formats
    """
    JSON = 0
    STRING = 1


class LoggerLevel(Enum):
    """
    Enum for logger levels
    """
    NOTSET = 0
    DEBUG = 1
    INFO = 2
    WARNING = 3
    ERROR = 4
    CRITICAL = 5


class Logger(object):
    """
    Log string and messages on kafka
    """

    def __init__(self, config: str or Bunch) -> None:
        """
        Initialize logger class
        Args:
            config: Get logger config by file path or bunch object
        """
        if type(config) == str:
            self._config = hp.get_config(path=config)
        else:
            self._config = config
        level = LoggerLevel.NOTSET
        if 'level' in self._config:
            level = self._config.level.upper()
        self._log_level = LoggerLevel[level] if level in LoggerLevel.__members__ else LoggerLevel.NOTSET

    def log(self, level: str, msg: str, **kwargs) -> bool:
        """
        Log messages with different levels
        Args:
            level: Log level
            msg: Log message
            **kwargs: More parameters for logging message
        Returns: Log string message or log message on kafka message broker
        """
        if 'func' in kwargs:
            func_object = kwargs['func']
            file = inspect.getfile(func_object)
            func = func_object.__name__
        else:
            file = inspect.stack()[2].filename
            func = inspect.stack()[2].function
        pid = os.getpid()
        log_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        if LoggerLevel[level].value >= self._log_level.value:
            logger_format = LoggerFormat.STRING.name.lower()
            if 'format' in self._config:
                logger_format = self._config.format.lower()
            if logger_format == LoggerFormat.JSON.name.lower():
                doc = {
                    'pid': pid,
                    'level': level,
                    'message': msg,
                    'file': file,
                    'function': func,
                    'time': log_time
                }
                if 'kafka' in self._config and 'active' in self._config.kafka and self._config.kafka.active:
                    producer = self._config.kafka.producer
                    with KafkaDataProducer(config=producer) as kafka:
                        kafka.produce_data(doc=doc, topic=producer.topic)
                else:
                    print(json.dumps(doc, indent=4))
                return True
            elif self._config.format == LoggerFormat.STRING.name.lower():
                print(f'{pid} - {log_time} {level} | message: {msg}, file: {file}, function: {func}')
                return True
            else:
                print('Logger format is not correct!')
                return False

    def debug(self, msg: str, **kwargs) -> bool:
        """
        Log debug message
        Args:
            msg: Log message
            **kwargs: More parameters for debug message
        Returns: Log debug massage based on string or json type
        """
        return self.log(level=LoggerLevel.DEBUG.name, msg=msg, **kwargs)

    def info(self, msg: str, **kwargs) -> bool:
        """
        Log info message
        Args:
            msg: Log message
            **kwargs: More parameters for info message
        Returns: Log info massage based on string or json type
        """
        return self.log(level=LoggerLevel.INFO.name, msg=msg, **kwargs)

    def error(self, msg: str, **kwargs) -> bool:
        """
        Log error message
        Args:
            msg: Log message
            **kwargs: More parameters for error message
        Returns: Log error massage based on string or json type
        """
        return self.log(level=LoggerLevel.ERROR.name, msg=msg, **kwargs)

    def warning(self, msg: str, **kwargs) -> bool:
        """
        Log warning message
        Args:
            msg: Log message
            **kwargs: More parameters for warning message
        Returns: Log warning massage based on string or json type
        """
        return self.log(level=LoggerLevel.WARNING.name, msg=msg, **kwargs)

    def critical(self, msg: str, **kwargs) -> bool:
        """
        Log critical message
        Args:
            msg: Log message
            **kwargs: More parameters for critical message
        Returns: Log critical massage based on string or json type
        """
        return self.log(level=LoggerLevel.CRITICAL.name, msg=msg, **kwargs)
