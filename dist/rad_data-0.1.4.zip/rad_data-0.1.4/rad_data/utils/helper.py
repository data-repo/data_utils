
import yaml
import json
from pathlib import Path
from rad_data.utils.bunch import Bunch


def get_config(path: str) -> Bunch:
    """
    Convert config yaml file to bunch object
    Args:
        path: File path for config file
    Returns: Bunch object

    """
    try:
        if not Path(path).exists():
            raise FileNotFoundError
        with open(path, 'r') as yaml_string:
            data = yaml.safe_load(yaml_string.read())
        return json.loads(json.dumps(data), object_hook=Bunch)
    except Exception as e:
        print(f'Error in get config from file, {e}')


def list_to_dict_by_key(list_of_dict: list, key: str) -> dict:
    """
    Convert list to dictionary by key
    Args:
        list_of_dict: List of dictionary
        key: Key name from dictionary in list
    Returns: Dictionary based on key value
    """
    docs = {}
    for item in list_of_dict:
        try:
            docs[str(item[key])] = item
        except Exception as e:
            print(f'Error in convert list to dictionary  by key, {e}')
    return docs
